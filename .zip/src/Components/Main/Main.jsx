import React, { useState } from "react";
import "./Main.css";
import UnAuthCard from "../Cards/UnAuthCard/UnAuthCard";
import SelectCard from "../SelectCard/SelectCard";

function Main() {
  const [DisplayCard, setDisplayCard] = useState(false);

  return (
    <div className="Main screen">
      {DisplayCard === "unauth" ? <UnAuthCard setDisplayCard={setDisplayCard} /> : null}
      {DisplayCard ? null : (
        <SelectCard setDisplayCard={setDisplayCard} DisplayCard={DisplayCard} />
      )}
    </div>
  );
}

export default Main;
